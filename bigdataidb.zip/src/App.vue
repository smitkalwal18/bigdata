<template>
  <div>
    <button @click="clearStoreButton">
      clearStore
    </button>
    <Datatable 
      ref="bigdata"
      :columns="cols" 
      v-if="items.length > 0" 
      :items="items" 
      :useStore="useStore" 
      :dbName="dbName" 
      :storeName="storeName" 
    ></Datatable>

    
  </div>
</template>

<script>
import Datatable from './components/Datatable.vue'

export default {
  name: 'App',
  components: {
    Datatable
  },
  data () {
      return {
              cols: [ 'albumId', 'id', 'title', 'url', 'thumbnailUrl'],
              items: [],
              useStore: true,
              dbName: "testDb138",
              storeName: "items138"
      }
  },
  mounted () {
    this.getdata()
  },
  methods: {
    async getdata (){
      await fetch('https://jsonplaceholder.typicode.com/photos')
        .then(response => response.json())
        .then(json => {
          console.log(json)
          this.items = json
        })

    },
    clearStoreButton () {
      const result = this.$refs.bigdata.clearStore('testDb138');
      console.log('result', result);
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
