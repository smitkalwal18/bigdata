<template>
  <table class="table">
      <thead>
          <tr>
              <th v-for="(column, index) in columns" :key="index"> {{column}}</th>
          </tr>
      </thead>
      <tbody>
          <tr v-for="(item, index) in rows" :key="index">
              <td v-for="(column, indexColumn) in columns" :key="indexColumn">{{item[column]}}</td>
          </tr>
      </tbody>
    </table>
</template>

<script>
import idbs from '../db/indexedDBService'

export default {
  name: 'Datatable',
  props: {
    columns: Array,
    items: Array,
    useStore: Boolean,
    dbName: null,
    storeName: null
  },
  data () {
    return {
      rows : []
    }
  },
  mounted () {

    if (this.useStore) {
      
      if (!this.dbName) {
        throw new TypeError("Property dbName missing")
      }
      if (!this.storeName) {
        throw new TypeError("Property storeName missing")
      }

      this.checkStorage()
      
    } else {
      this.rows = JSON.parse(JSON.stringify(this.items));
    }
  },
  methods: {

    checkStorage: async function () {

      const dbName = this.dbName;
      const storeName = this.storeName;

      this.rows = await idbs.checkStorage(dbName, storeName);
      console.log('this.rows', this.rows)
      if (this.rows === undefined) {
        if (this.items) {
          const data = JSON.parse(JSON.stringify(this.items));
          this.rows = await idbs.saveToStorage(dbName, storeName, data);
        }
        if (this.rows === null) this.rows = []
      }
    },
    clearStore: function (dbName) {
      // const dbName = this.clearStore;

      // const delReq = idbs.clearStorage(dbName);
      // return delReq;
      return idbs.clearStorage(dbName)
        .then(
            function(response) {
              console.log('response', response);
              return response;
        })

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
