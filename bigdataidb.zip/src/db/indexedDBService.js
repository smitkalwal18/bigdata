import { openDb, deleteDb } from 'idb'
const  version = 1;

const dbPromise = async (dbName, storeName) => {
  if (!('indexedDB' in window)) {
    throw new Error('Browser does not support IndexedDB')
  }

  return openDb(dbName, version, upgradeDb => {
    console.log('upgradeDb.objectStoreNames', upgradeDb.objectStoreNames)
    if (!upgradeDb.objectStoreNames.contains(storeName)) {
      upgradeDb.createObjectStore(storeName, {autoIncrement: true})
    }
  })
}

const dbDelete = async (dbName) => {
  if (!('indexedDB' in window)) {
    throw new Error('Browser does not support IndexedDB')
  }

  return deleteDb(dbName)
}

const checkStorage = async (database, storeName) => {
  try {
    const db = await dbPromise(database, storeName)
    const tx = db.transaction(storeName, 'readonly')
    const store = tx.objectStore(storeName)

    return store.get(storeName)
  } catch (error) {
    return error
  }
}

const saveToStorage = async (database, storeName, data) => {
  try {
    const db = await dbPromise(database, store)
    const tx = db.transaction(storeName, 'readwrite')
    const store = tx.objectStore(storeName)
    // console.log('saveToStorage data', data)
    store.put(data, storeName)
    if (tx.complete) {
      return store.get(storeName)
    }
    
  } catch (error) {
    return error
  }
}

const clearStorage = async (dbName) => {
  try {
    // const req = await window.indexedDB.deleteDatabase(dbName)
    // req.onsuccess = function (e) {
    //     console.log("Deleted database successfully")
    // };
    // req.onerror = function (e) {
    //     console.log("Couldn't delete database");
    // };
    // req.onblocked = function (e) {
    //     console.log("Couldn't delete database due to the operation being blocked");
    // };

    return dbDelete(dbName);
  } catch (error) {
    return error
  }
}

export default {
  checkStorage,
  saveToStorage,
  clearStorage
}
