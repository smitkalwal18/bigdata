const DB_VERSION = 1;
let DB;

export default {

	async getDb(database, storeName) {
		return new Promise((resolve, reject) => {

			if (DB) { return resolve(DB); }
			console.log('OPENING DB', DB);
			let request = window.indexedDB.open(database, DB_VERSION);

			request.onerror = e => {
				console.log('Error opening db', e);
				reject('Error');
			};

			request.onsuccess = e => {
				DB = e.target.result;
				resolve(DB);
			};

			request.onupgradeneeded = e => {
				console.log('onupgradeneeded');
				let db = e.target.result;
				db.createObjectStore(storeName);
			};
		});
	},
	async checkStorage(database, storeName) {

		let db = await this.getDb(database, storeName);

		return new Promise(resolve => {

			let trans = db.transaction([storeName], 'readonly');
			trans.oncomplete = () => {
				resolve();
			};

			let store = trans.objectStore(storeName);

			var objectStoreRequest = store.get(storeName);
			objectStoreRequest.onsuccess = function (event) {
				// report the success of our request			
				var myRecord = objectStoreRequest.result;
				resolve(myRecord);
			};

		});
	},

	async saveToStorage(database, storeName, data) {

		let db = await this.getDb(database, storeName);

		return new Promise((resolve, reject) => {

			let trans = db.transaction([storeName], 'readwrite');
			trans.oncomplete = () => {
				resolve();
			};

			trans.onerror = function(event) {
				reject();
			};		

			let store = trans.objectStore(storeName);

			const objectStoreRequest = store.add(data, storeName);

			objectStoreRequest.onsuccess = function(event) {
				// report the success of our request
				var getobjectStore = store.get(storeName);
				
				getobjectStore.onsuccess = function(event) {
					var myRecord = getobjectStore.result;
					console.log(myRecord)
					resolve(myRecord);
				};
				
			};

		});

	},

	async clearStorage(dbName) {
		try {
			const req = await window.indexedDB.deleteDatabase(dbName)
			req.onsuccess = function (e) {
				console.log("Deleted database successfully")
			};
			req.onerror = function (e) {
				console.log("Couldn't delete database");
			};
			req.onblocked = function (e) {
				console.log("Couldn't delete database due to the operation being blocked");
			};

		} catch (error) {
			return error
		}
	}

}